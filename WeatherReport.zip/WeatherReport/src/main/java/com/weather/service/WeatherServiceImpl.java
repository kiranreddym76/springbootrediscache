package com.weather.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.weather.model.WeatherReport;

@Service
public class WeatherServiceImpl implements WeatherService {

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	private Environment env;

	public WeatherReport getWeather(String cityName) {
		String url = env.getProperty("weather.base.uri") + cityName + env.getProperty("symbol.and")
				+ env.getProperty("weather.app.id");
		System.out.println("url" + url);
		HttpHeaders headers = new HttpHeaders();
		headers.set(env.getProperty("header.appid"), env.getProperty("header.appid.value"));
		HttpEntity<String> requestEntity = new HttpEntity<>(null, headers);
		ResponseEntity<WeatherReport> weatherReport = restTemplate.exchange(url, HttpMethod.GET, requestEntity,
				WeatherReport.class);
		return weatherReport.getBody();
	}
}
