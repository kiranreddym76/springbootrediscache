package com.weather.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.weather.model.WeatherReport;
import com.weather.service.WeatherServiceImpl;

@RestController
public class WeatherController {
	
   private final Logger LOG = LoggerFactory.getLogger(getClass());
	
	@Autowired
	WeatherServiceImpl weatherService;
	
	@Cacheable(value = "WeatherReport", key = "#cityName")
	@GetMapping("/weatherReport/{cityName}")
    @ResponseBody
    public WeatherReport getWeather(@PathVariable String cityName){
	    WeatherReport weatherReport = weatherService.getWeather(cityName);
	     LOG.info("Getting Weather details for cityName {}.", cityName);
	     return weatherReport;
    }
}
