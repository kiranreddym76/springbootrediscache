package com.weather.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Main implements Serializable{
	
	private static final long serialVersionUID = 7156526077883281626L;
	
	@JsonProperty("temp")
	private long temperature;
	
	@JsonProperty("pressure")
	private int pressure;
	
	@JsonProperty("humidity")
	private int humidity;

	public long getTemperature() {
		return temperature;
	}

	public void setTemperature(long temperature) {
		this.temperature = temperature;
	}

	public int getPressure() {
		return pressure;
	}

	public void setPressure(int pressure) {
		this.pressure = pressure;
	}

	public int getHumidity() {
		return humidity;
	}

	public void setHumidity(int humidity) {
		this.humidity = humidity;
	}
	
}
