package com.weather.model;

import java.io.Serializable;
import java.util.ArrayList;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WeatherReport implements Serializable{

	private static final long serialVersionUID = 7156526077883281625L;

	@JsonProperty("weather")
	public ArrayList<Weather> weather;
	
	@JsonProperty("wind")
	public Wind wind;
	
	@JsonProperty("main")
	public Main main;

	public ArrayList<Weather> getWeather() {
		return weather;
	}

	public void setWeather(ArrayList<Weather> weather) {
		this.weather = weather;
	}

	public Wind getWind() {
		return wind;
	}

	public void setWind(Wind wind) {
		this.wind = wind;
	}

	public Main getMain() {
		return main;
	}

	public void setMain(Main main) {
		this.main = main;
	} 
	
}
